package com.example.multinotes;

import java.util.ArrayList;
import java.util.Date;

public class Note {
    private String name;
    private ArrayList<String> content;
    private Date dateCreate;
    private Date alarmTime;

    public Note(String name, ArrayList<String> content, Date dateCreate, Date alarmTime) {
        this.name = name;
        this.content = content;
        this.dateCreate = dateCreate;
        this.alarmTime = alarmTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<String> getContent() {
        return content;
    }

    public void setContent(ArrayList<String> content) {
        this.content = content;
    }

    public Date getDateCreate() {
        return dateCreate;
    }

    public void setDateCreate(Date dateCreate) {
        this.dateCreate = dateCreate;
    }

    public Date getAlarmTime() {
        return alarmTime;
    }

    public void setAlarmTime(Date alarmTime) {
        this.alarmTime = alarmTime;
    }
}
